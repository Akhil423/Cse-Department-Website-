<script type="text/javascript">
$(function() {
    $(".menu ul li a").on("click", function() {
        $(this).addClass("active");
    });
});
</script>
