
<?php 
//Connects to your Database
mysql_connect("localhost", "root", "root") or die(mysql_error()); 
mysql_select_db("user") or die(mysql_error()); 

//This code runs if the form has been submitted

if (isset($_POST['submit'])) { 

//This makes sure they did not leave any fields blank
if (!$_POST['username'] | !$_POST['pass'] | !$_POST['pass2'] ) {
echo "<script> alert(\"You did not complete all of the required fields\");  window.location=\"http://localhost/cucse.com/add.php\";</script>";
}

// checks if the username is in use
if (!get_magic_quotes_gpc()) {
	$_POST['username'] = addslashes($_POST['username']);
}

$usercheck = $_POST['username'];
echo $usercheck;
$check = mysql_query("SELECT username FROM login WHERE username = '$usercheck'") 
or die(mysql_error());
$check2 = mysql_num_rows($check);

//if the name exists it gives an error
if ($check2 != 0) {
 	die('Sorry, the username '.$_POST['username'].' is already in use.');
}

// this makes sure both passwords entered match
if ($_POST['pass'] != $_POST['pass2']) {
//	die('Your passwords did not match. ');
}

// here we encrypt the password and add slashes if needed
$_POST['pass'] = md5($_POST['pass']);

if (!get_magic_quotes_gpc()) {
	$_POST['pass'] = addslashes($_POST['pass']);
	$_POST['username'] = addslashes($_POST['username']);
}

// now we insert it into the database
$insert = "INSERT INTO login (username, password) VALUES ('".$_POST['username']."', '".$_POST['pass']."')";
$add_member = mysql_query($insert);
echo "<script>alert(\"Registered!Thank you, you have registered - you may now login\"); window.location=\"http://localhost/cucse.com/login.php\";
</script>";
?>

 <?php 
 }

 else 
 {	 
 include_once 'header1.php'; 
 ?>
 
 <?php
 }
 ?> 
