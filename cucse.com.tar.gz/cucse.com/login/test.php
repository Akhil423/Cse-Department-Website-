<?php 

//Connects to your Database 
$conect = mysqli_connect("localhost","root","root", "user") or die(mysql_error()); 
 