<!DOCTYPE html>
<head>
<link rel="stylesheet" href="css/cucse.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<script src="js/modernizr.custom.js"></script>
<script src="cucse.js"></script>
</head>
<body>
	<diV class="menu-wrap">
<center><h1><i>Welcome To Cse Department!!</i></h1></center>
		<div class="menu">
			<ul>
				<li><a href="index.php">HOME</a></li>
				<li><a href="techevents.php">TECH EVENTS</a></li>
				<li><a href="#">CODE GROUND</a></li>
				<li><a href="#">ABOUT US</a></li>
				<li><a href="#">CONTACT US</a></li>
				<li><a href="#">FORUMS</a></li>
				<li id="lot"><span><a href="login.php"><strong>Login/Signup</strong></a></span></li>
			</ul>
		</div>
	</diV>


