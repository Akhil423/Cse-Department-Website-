<!DOCTYPE html>
<head>
<link rel="stylesheet" href="css/cucse.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<script src="js/modernizr.custom.js"></script>
<script src="cucse.js"></script>
</head>
<body>
	<diV class="menu-wrap">
	<center><h1><i>Welcome To Cse Department!!</i></h1></center>
		<div class="menu">
			<ul>
				<li><a href="index.php">HOME</a></li>
				<li><a href="techevents.php">TECH EVENTS</a></li>
				<li><a href="#">CODE GROUND</a></li>
				<li><a href="#">ABOUT US</a></li>
				<li><a href="#">CONTACT US</a></li>
				<li><a href="#">FORUMS</a></li>
				<li id="lot"><span><a href="login.php"><strong>Login/Signup</strong></a></span></li>
			</ul>
		</div>
	</diV>

<!--<form id="lol"action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">-->
<div>
 <div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4">
           <h1 id="lol"class="text-center login-title">Sign in to continue to cse</h1><br>
    <div class="account-wall">
              <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post"> 

 <table border="0"> 

 <tr><td colspan=2><h1>Login</h1></td></tr> 

 <tr><td>Username:</td><td> 

 <input type="text" name="username" maxlength="40"> 

 </td></tr> 

 <tr><td>Password:</td><td> 

 <input type="password" name="pass" maxlength="50"> 

 </td></tr> 

 <tr><td colspan="2" align="right"> 

 <input type="submit" name="submit" value="Login"> 

 </td></tr> 

 </table> 

 </form> 
            </div>
           <a href="add.php" class="text-center new-account">Sign Up Now!</a>
            
        </div>
    </div>
</div>
</div>
</body>
</html>