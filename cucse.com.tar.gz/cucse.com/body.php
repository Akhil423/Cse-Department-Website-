	<div class="container demo-3">
			<!-- Top Navigation -->
			
			<ul class="grid cs-style-3">
				<li>
					<figure>
						<img src="images/4.png" alt="img04">
						<figcaption>
							<h3>Gallery</h3>
							<span>Cu_Cse</span>
							<a href="#">go here!</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/1.png" alt="img01">
						<figcaption>
							<h3>events</h3>
							<span>Cu_Cse</span>
							<a href="#">go here!</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/2.png" alt="img02">
						<figcaption>
							<h3>Research</h3>
							<span>Cu_Cse</span>
							<a href="#">go here!</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/5.png" alt="img05">
						<figcaption>
							<h3>tutorial</h3>
							<span>Cu_Cse</span>
							<a href="#">go here!</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/3.png" alt="img03">
						<figcaption>
							<h3>idea_room</h3>
							<span>Cu_Cse</span>
							<a href="#">go here!</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/6.png" alt="img06">
						<figcaption>
							<h3>Game Center</h3>
							<span>Cu_Cse</span>
							<a href="#">go here!</a>
						</figcaption>
					</figure>
				</li>
			</ul>
		</div><!-- /container -->
		<div class="menu" >
			<ul>
				<li><a href="#">HOME</a></li>
				<li><a href="#">TECH EVENTS</a></li>
				<li><a href="#">CODE GROUND</a></li>
				<li><a href="#">ABOUT US</a></li>
				<li><a href="#">CONTACT US</a></li>
				<li><a href="#">FORUMS</a></li>
			</ul>
		</div>
</body>
</html>
