<!DOCTYPE html>
<meta charset="utf-8">
<head>
  <title>Tech events</title>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
  <style>
  #border{
           border-bottom-color: 50px solid black;
           border-left-color:50px solid black;
           border-right-color:50px solid black;
           border-top-color:50px solid blaclk;  
  
  }
  .error {color: #FF0000;}
  #nav{
      width:910px;
      height:80px;    
     
      color: white;
      background-color: black;
      margin-left: 200px;
      margin-top: 50px;
      text-align: center;
      text-decoration: blink;
      align-content: center;
      padding-top: 20px;
      }
  #section{
      width:900px;
      height:600px;    
      
      border-right:5px solid black;
      border-top:20px; 
      border-left:5px solid black;
      background-color:white;
      margin-left: 200px;
      }
      #form{
padding-top:20px;  
border:20px solid red;    
      }
  </style>
</head>
<body id="border">
<div id="nav">
<h1> <center>Registration Page</center></h1>
</div>
<div id="section">
<section>
	

 
 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" name="myForm" onsubmit="return(validate());" method="post" id="form">
 <fieldset>


 <legend>Register here</legend>
<pre>Name          : <input type="text" name="name" value=  ""placeholder=" name" ><span class="error">* <?php echo $nameErr;?></span> <<br><br></pre>
<pre>Uid           : <input type="text" name="uid" placeholder="uid" ><span class="error">* <?php echo $uidErr;?></span><br><br></pre>
<pre>Email         : <input type="email" name="email" value="" placeholder="email" ><span class="error">* <?php echo $emailErr;?></span><br><br></pre>
<pre>Gender        :female <input type="radio" name="gender" placeholder="gender" value="female" ><span class="error">* <?php echo $genderErr;?></span>male <input type="radio" name="gender" placeholder="gender" value="male"><span class="error">* <?php echo $genderErr;?></span><br><br></pre>
<pre>Contact Number: <input type="numeric" name="contact" value="" placeholder="number" ><span class="error">* <?php echo $contact_numberErr;?></span><br><br></pre>
<input type="submit" color="blue">
<input type="reset">
</fieldset>
</form>
</section>
<script type="text/javascript">
   <!--
      // Form validation code will come here.
      function validate()
      {
      
         if( document.myForm.name.value == "" )
         {
            alert( "Please provide your name!" );
            document.myForm.name.focus() ;
            return false;
         }
         
         if( document.myForm.email.value == "" )
         {
            alert( "Please provide your Email!" );
            document.myForm.email.focus() ;
            return false;
         }
         
         if( document.myForm.contact.value == "" ||
         isNaN( document.myForm.contact.value ) ||
         document.myForm.contact.value.length != 10 )
         {
            alert( "Please provide a number in the format #####." );
            document.myForm.Zip.focus() ;
            return false;
         }
         
         if( document.myForm.uid.value == "-1" )
         {
            alert( "Please provide your country!" );
            return false;
         }
         return( true );
      }
   //-->
</script>

<?php


$servername = "localhost";/*login details*/
$username = "root";
$password = "root";
$dbname = "iit";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);/*connecting to database*/
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
    if(isset($_POST['submit'])) { 
       $name = $_POST['name'];
       $uid = $_POST['uid'];
       $email = $_POST['email'];
       $gender = $_POST['gender'];
       $contact_number =$_POST['contact'];
       
  
  if(empty($name)  || empty($uid)   || empty($email)  || empty($gender)   || empty($contact_number)   ){
    echo "<script>
          alert('enter the fields correctly?')    
    </script>";
    }
   
   else{ //sql runs from here
      $mysql = "INSERT INTO java (name, uid,email,gender,contact)
    VALUES ('$name','$uid','$email','$gender','$contact_number')";
    // use exec() because no results are returned
    $conn->exec($mysql);
    
    
     
    //javascript for redirecting a to tech events page
    echo "<script>
             alert('Registration Successful!')
             window.location='techevents.php' ;   
          </script>
    ";
   }}
}
  catch(PDOException $e)
    {
    echo $mysql . "<br>" . $e->getMessage();
    }

$conn = null;
?>

</div>
</body>

</html>
