
<head>
<link rel="stylesheet" href="template/css/cucse.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="template/css/default.css" />
		<link rel="stylesheet" type="text/css" href="template/css/component.css" />
		<script src="template/js/modernizr.custom.js"></script>
<script src="template/cucse.js"></script>
</head>
<body>
	<diV class="menu-wrap">
		<div class="menu">
			<ul>
				<li><a href="#">HOME</a></li>
				<li><a href="#">TECH EVENTS</a></li>
				<li><a href="#">CODE GROUND</a></li>
				<li><a href="#">ABOUT US</a></li>
				<li><a href="#">CONTACT US</a></li>
				<li><a href="#">FORUMS</a></li>
				<li id="lol"><span><a href="login/add.php"><strong>Login/Signup</strong></a></span></li>
			</ul>
		</div>
	</diV>
	</body>